package ru.eltech.kursovaya.api;

public class Cities {
    private String id;
    private String name;
}