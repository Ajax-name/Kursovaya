package ru.eltech.kursovaya.api;

public class ShopCentre{
    private String id;
    private String name;
    private String jpgPath;
    private String description;
}